Thanks for cloning this repository!
IMPORTANT: Make sure to set your gitignore_global.txt file TO THE ONE PROVIDED IN THIS REPOSITORY
If you are using SourceTree, press Tools > Options > Git > Global Ignore List: and set it to the one you cloned in this repos.

1)
    Once you have cloned the repository to some folder (eg. mark-xi), set your Windriver workspace to that folder.
    Example: Cloned to D:\Repositories\Mark-XI    When you start Windriver (or press File > Switch Workspace) set D:\Repositories\Mark-XI as your workspace.
    
2)
    Since the repository is not going to take Windriver project files or compiled programs, you are going to need to reimport a local project.
    Select File > Import > General > Existing Projects into Workspace, and press Next
    Click Browse, and without selecting anything, press OK.
    Projects should appear in the "Projects:" box.
    Press Finish to add the projects.